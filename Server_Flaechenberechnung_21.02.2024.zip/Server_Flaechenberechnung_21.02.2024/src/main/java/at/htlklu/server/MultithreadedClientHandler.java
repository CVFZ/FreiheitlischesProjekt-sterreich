package at.htlklu.server;

import java.io.*;
import java.net.Socket;

public class MultithreadedClientHandler extends Thread{
    private Socket client;
    private BufferedReader in;
    private BufferedWriter out;
    public static double roundOnThreeDigits(double value){
        return (double)Math.round(value*1000)/1000;
    }
    public MultithreadedClientHandler(Socket client) throws IOException {
        this.client = client;
        this.in = new BufferedReader(new InputStreamReader((this.client.getInputStream())));
        this.out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
    }

    @Override
    public void run() {
        try {
            out.write("--- Flächenberechnung ---");
            out.newLine();
            boolean exit = false;
            while(!exit) {
                out.write("Bitte geben Sie K für Kreis, R für Rechteck oder EXIT an:");
                out.newLine();
                out.flush();

                String command = in.readLine();

                switch (command) {
                    case "K":
                        out.write("Bitte geben Sie den Radius ein:");
                        out.newLine();
                        out.flush();
                        double radius = Double.parseDouble(in.readLine());
                        double area = Math.pow(radius,2)*Math.PI;
                        double circumference = 2*radius*Math.PI;
                        out.write(String.format("Kreisberechnung: Radius = %.3f, Flaeche = %.3f, Umfang = %.3f",roundOnThreeDigits(radius),roundOnThreeDigits(area),roundOnThreeDigits(circumference)));
                        out.newLine();
                        out.flush();
                        break;
                    case "R":
                        out.write("Bitte geben Sie die Länge des Rechtecks ein:");
                        out.newLine();
                        out.flush();
                        double width = Double.parseDouble(in.readLine());
                        out.write("Bitte geben Sie die Breite des Rechtecks ein:");
                        out.newLine();
                        out.flush();
                        double height = Double.parseDouble(in.readLine());
                        area = width*height;
                        circumference = 2*width+2*height;
                        out.write(String.format("Rechteckberechnung: Groesse = %.3f x %.3f, Flaeche = %.3f, Umfang = %.3f",roundOnThreeDigits(width),roundOnThreeDigits(height),roundOnThreeDigits(area),roundOnThreeDigits(circumference)));
                        out.newLine();
                        out.flush();
                        break;
                    case "EXIT":
                        exit=true;
                        break;
                    default:
                        out.write("Invalid command!");
                        out.newLine();
                        out.flush();
                        break;
                }
            }
            out.write("Ende der Berechnungen");
            out.newLine();
            out.flush();
            out.close();
            in.close();
            client.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
