package at.htlklu.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MultithreadedServer {
    public static void main(String[] args) {

            try {
                ServerSocket server = new ServerSocket(8989);
                while(true){
                    Socket client = server.accept();
                    MultithreadedClientHandler m = new MultithreadedClientHandler(client);
                    m.start();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

    }
}
