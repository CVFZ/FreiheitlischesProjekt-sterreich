package at.htlklu.server;

import java.io.IOException;
import java.net.ServerSocket;

public class MultithreadedServer {
    public static void main(String[] args) {
        boolean isRunning = true;
        try(ServerSocket server = new ServerSocket(5005)){
            while(isRunning){
                new ClientHandler(server.accept()).start();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
