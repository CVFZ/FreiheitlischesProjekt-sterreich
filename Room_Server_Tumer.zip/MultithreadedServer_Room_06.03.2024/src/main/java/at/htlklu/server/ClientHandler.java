package at.htlklu.server;

import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread{

    private boolean run = true;
    public void stopThread(){
        run = false;
    }
    private Socket clientSocket = null;

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
            RoomProtocol protocol = new RoomProtocol(this);
            String line = "";
            while(run){
                line = in.readLine();
                out.write(protocol.generateOutput(line));
                out.newLine();
                out.flush();
            }
            in.close();
            out.close();
            clientSocket.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
