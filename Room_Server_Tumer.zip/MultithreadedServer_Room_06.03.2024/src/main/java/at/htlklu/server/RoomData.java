package at.htlklu.server;

import java.time.LocalTime;

public class RoomData {
    private LocalTime time;
    private String roomNumber;
    private double temperature;

    public RoomData(LocalTime time, String roomNumber, double temperature) {
        this.time = time;
        this.roomNumber = roomNumber;
        this.temperature = temperature;
    }


    public LocalTime getTime() {
        return time;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
}
