package at.htlklu.server;

import java.io.IOException;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.stream.Collectors;

public class RoomProtocol {
    public RoomProtocol(ClientHandler client) {
        this.client = client;
    }

    private static synchronized void addEntry(RoomData roomData){
        List<RoomData> entries = roomDataList.stream().filter((RoomData p)->p.getRoomNumber().equalsIgnoreCase((roomData.getRoomNumber()))).toList();
        if(entries.size()>0){
            roomDataList.remove(entries.get(0));
        }
        roomDataList.add(roomData);
    }
    private static ArrayList<RoomData> roomDataList = new ArrayList<RoomData>();

    private ClientHandler client = null;
    private ClientState state = ClientState.START;
    private String clientName = null;
    public String generateOutput(String input) throws IOException {
        if(state==ClientState.START && input.contains("LOGON")){
            String[] splittedCommand = input.split(" ");
            clientName = splittedCommand[1];
            state = ClientState.LOGON;
            return "HELLO "+clientName;
        }
        if(state == ClientState.LOGON && input.contains("SET")){
            String[] splittedCommand = input.split(" ");
            String[] data = splittedCommand[1].split(";");
            addEntry(new RoomData(LocalTime.now(),data[0],Double.parseDouble(data[1])));
            return "Temperaturwert gespeichert.";
        }
        if(state == ClientState.LOGON && input.contains("GET")){
            String[] splittedCommand = input.split(" ");
            String roomNumber = splittedCommand[1];
            List<RoomData> roomDataEntries = roomDataList.stream().filter(p->p.getRoomNumber().equalsIgnoreCase(roomNumber)).toList();
            if(roomDataEntries.size()>0){
                RoomData requestedData = roomDataEntries.get(0);
                return "Room:"+requestedData.getRoomNumber()+" Time:"+requestedData.getTime().format(new DateTimeFormatterBuilder().toFormatter())+" Temperatur: "+requestedData.getTemperature()+"°C";
            }
            else{
                return "Keine Daten vorhanden.";
            }
        }
        if(state == ClientState.LOGON && input.equalsIgnoreCase("EXIT")){
            client.stopThread();
            return "Verbindung beendet.";
        }
        if(state==ClientState.START){
            client.stopThread();
            return "Error: Not logged on!";
        }
        return "Error: Unknown command";
    }
}

