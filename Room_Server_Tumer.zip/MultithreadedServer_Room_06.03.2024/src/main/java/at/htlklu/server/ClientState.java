package at.htlklu.server;

public enum ClientState {
    START,
    LOGON,
    END,
}
