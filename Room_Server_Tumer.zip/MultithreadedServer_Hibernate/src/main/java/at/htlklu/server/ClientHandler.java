package at.htlklu.server;

import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread{
    private Socket client;
    private boolean run = true;

    public void stopThread(){
        this.run = false;
    }
    public ClientHandler(Socket client) {
        this.client=client;
    }

    @Override
    public void run() {
        try {
            BufferedWriter w = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader r = new BufferedReader(new InputStreamReader(client.getInputStream()));
            Protocol p = new Protocol(this);
            while(run){
                String line = r.readLine();
                w.write(p.generateAnswer(line));
                w.newLine();
                w.flush();
            }
            w.close();
            r.close();
            client.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
