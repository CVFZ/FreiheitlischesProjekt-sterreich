package at.htlklu.server;

import at.htlklu.database.RoomDataDAO;
import at.htlklu.entities.RoomData;

import java.time.LocalDateTime;

public class Protocol {

    private ClientHandler clientHandler;
    private ClientState state=ClientState.START;
    private String clientName;
    public Protocol(ClientHandler clientHandler) {
        this.clientHandler = clientHandler;
    }

    public String generateAnswer(String input){
        if(state==ClientState.START && input.contains("LOGON")){
            String[] splittedCommand = input.split(" ");
            clientName = splittedCommand[1];
            state = ClientState.LOGON;
            return "HELLO "+clientName;
        }
        if(state == ClientState.LOGON && input.contains("SET")){
            String[] splittedCommand = input.split(" ");
            String[] data = splittedCommand[1].split(";");
            RoomDataDAO.setRoomData(new RoomData(data[0],Double.parseDouble(data[1]),LocalDateTime.now()));
            return "Temperaturwert gespeichert.";
        }
        if(state == ClientState.LOGON && input.contains("GET")){
            String[] splittedCommand = input.split(" ");
            String roomNumber = splittedCommand[1];
           RoomData requestedData = RoomDataDAO.findByRoomId(roomNumber);
            if(requestedData!=null){
                System.out.println(requestedData);
                return "Room:"+requestedData.getRoomNumber()+" Time:"+requestedData.getTime()+" Temperatur: "+requestedData.getTemperature()+"°C";
            }
            else{
                return "Keine Daten vorhanden.";
            }
        }
        if(state == ClientState.LOGON && input.equalsIgnoreCase("EXIT")){
            clientHandler.stopThread();
            return "Verbindung beendet.";
        }
        if(state==ClientState.START){
            clientHandler.stopThread();
            return "Error: Not logged on!";
        }
        return "Error: Unknown command";
    }
    }
