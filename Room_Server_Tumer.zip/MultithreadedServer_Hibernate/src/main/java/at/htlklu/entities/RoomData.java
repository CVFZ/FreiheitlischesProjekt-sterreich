package at.htlklu.entities;

import jakarta.persistence.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "roomData")
public class RoomData {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "roomNumber")
    private String roomNumber;
    @Basic
    @Column(name = "temperature")
    private double temperature;
    @Basic
    @Column(name = "time")
    private LocalDateTime time;

    public RoomData() {
    }

    public RoomData(String roomNumber, double temperature, LocalDateTime time) {
        this.roomNumber = roomNumber;
        this.temperature = temperature;
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RoomData roomData = (RoomData) o;

        if (id != roomData.id) return false;
        if (Double.compare(temperature, roomData.temperature) != 0) return false;
        if (roomNumber != null ? !roomNumber.equals(roomData.roomNumber) : roomData.roomNumber != null) return false;
        if (time != null ? !time.equals(roomData.time) : roomData.time != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + (roomNumber != null ? roomNumber.hashCode() : 0);
        temp = Double.doubleToLongBits(temperature);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (time != null ? time.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RoomData{" +
                "id=" + id +
                ", roomNumber='" + roomNumber + '\'' +
                ", temperature=" + temperature +
                ", time=" + time +
                '}';
    }
}
