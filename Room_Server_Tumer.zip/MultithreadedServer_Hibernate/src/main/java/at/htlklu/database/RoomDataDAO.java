package at.htlklu.database;

import at.htlklu.entities.RoomData;
import jakarta.persistence.EntityManager;

import java.util.List;

public class RoomDataDAO {
    public static RoomData findByRoomId(String id){
        EntityManager em = JpaUtil.getEntityManager();
        List<RoomData> roomDataList = em.createQuery("From RoomData where roomNumber=?1", RoomData.class).setParameter(1,id).getResultList();
        return roomDataList.isEmpty()?null:roomDataList.get(0);
    }

    public static void setRoomData(RoomData newRoomdata){
        EntityManager em = JpaUtil.getEntityManager();
        RoomData entry = findByRoomId(newRoomdata.getRoomNumber());
        em.getTransaction().begin();
     if(entry==null){
        entry=newRoomdata;
        em.persist(entry);
        }
       else{
           entry.setTemperature(newRoomdata.getTemperature());
           entry.setTime(newRoomdata.getTime());
           em.merge(entry);
     }
       em.getTransaction().commit();
    }
}
