package at.htlklu.database;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
public class JpaUtil {
    private static final String PERSISTENCE_UNIT_NAME = "roommanagement";
    private static EntityManagerFactory factory = null;
    private static EntityManager entityManager = null;

    // singleton design pattern, to get exactly one object / always the same object
    public static EntityManagerFactory getFactory() {
        if(factory == null) {
            factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        }
        return factory;
    }

    public static EntityManager getEntityManager() {
        if (entityManager == null || !entityManager.isOpen()){
            entityManager = getFactory().createEntityManager();
        }
        return entityManager;
    }

    public static void shutdown() {
        if(entityManager != null && entityManager.isOpen()){
            entityManager.close();
        }
        entityManager = null;
        if(factory != null) {
            factory.close();
            factory = null;
        }
    }
}

