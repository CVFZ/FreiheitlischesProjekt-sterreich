package at.htlklu.database;

import at.htlklu.entities.RoomData;

import java.time.LocalDateTime;
import java.time.LocalTime;

public class Test {
    public static void main(String[] args) {
        RoomData r1 = new RoomData("R1",10.1, LocalDateTime.now());
        RoomDataDAO.setRoomData(r1);
        System.out.println(RoomDataDAO.findByRoomId("R1"));
        RoomData r2 = new RoomData("R1",9.8, LocalDateTime.now());
        RoomDataDAO.setRoomData(r2);
        System.out.println(RoomDataDAO.findByRoomId("R1"));
    }
}
