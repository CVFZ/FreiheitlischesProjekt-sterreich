package at.htlklu;

public class Protocol {
    ClientState clientState = ClientState.START;
    ClientHandler clientHandler;

    public Protocol(ClientHandler clientHandler) {
        this.clientHandler = clientHandler;
    }

    public String generateOutput(String input){
        if(clientState==ClientState.START && input.equalsIgnoreCase("H")){
            clientState = ClientState.H;
            return "Gib mir ein E";
        }
        else if(clientState==ClientState.H && input.equalsIgnoreCase("E")){
            clientState = ClientState.E;
            return "Gib mir ein L";
        }
        else if(clientState==ClientState.E && input.equalsIgnoreCase("L")){
            clientState = ClientState.L1;
            return "Gib mir ein L";
        }
        else if(clientState==ClientState.L1 && input.equalsIgnoreCase("L")){
            clientState = ClientState.L2;
            return "Gib mir ein O";
        }
        else if(clientState==ClientState.L2 && input.equalsIgnoreCase("O")){
            clientState = ClientState.O;
            this.clientHandler.stopThread();
            return "HELLO World!";
        }
        else{
            clientState = ClientState.START;
            return "Fehler, zurück zum Start! Gib mir ein H";
        }
    }
}
