package at.htlklu;

import java.io.IOException;
import java.net.ServerSocket;

public class Server {
    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(7878)) {
            while(true){
                new ClientHandler(server.accept()).start();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
