package at.htlklu;

import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread{
    public Socket clientSocket;
    public boolean run = true;

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    public void stopThread(){
        this.run=false;
    }
    @Override
    public void run() {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             BufferedWriter w = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));) {
            Protocol p = new Protocol(this);
            w.write("Gib mir ein H");
            w.newLine();
            w.flush();
            while(run){
              String line = r.readLine();
              if(line == null){
                  this.run=false;
                  break;
              }
              String output = p.generateOutput(line);
              w.write(output);
              w.newLine();
              w.flush();
            }
            w.close();
            r.close();
            clientSocket.close();
        } catch (IOException e) {
            this.run=false;
            throw new RuntimeException(e);
        }
    }
}
