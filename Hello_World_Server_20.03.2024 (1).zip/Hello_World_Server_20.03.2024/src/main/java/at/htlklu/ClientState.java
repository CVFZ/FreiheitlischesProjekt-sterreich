package at.htlklu;

public enum ClientState {
    START,
    H,
    E,
    L1,
    L2,
    O,
    STOP
}
