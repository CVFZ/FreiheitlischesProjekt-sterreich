package at.htlklu.server;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class MultithreadedClientHandler implements Runnable{
    private static int counter = 0;
    private Socket client;

    private synchronized int incrementCounter(){
        counter++;
        return counter;
    }
    public MultithreadedClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            out.write("Commands: next to increment the counter, EXIT to end the connection");
            out.newLine();
            out.flush();
            boolean exit = false;
            while(!exit){
                String command = in.readLine();
                switch (command){
                    case "next":;
                    int currentCount = incrementCounter();
                    out.write("Counter Value: "+currentCount);
                    out.newLine();
                    out.flush();
                    break;
                    case "EXIT":
                        exit = true;
                        break;
                    default:
                        out.write("Commands: next to increment the counter, EXIT to end the connection");
                        out.newLine();
                        out.flush();

                }
            }
            out.write("Verbindung geschlossen");
            out.newLine();
            out.flush();
            out.close();
            in.close();
            client.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
