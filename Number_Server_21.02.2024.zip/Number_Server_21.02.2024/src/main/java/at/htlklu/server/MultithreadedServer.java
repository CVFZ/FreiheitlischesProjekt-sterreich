package at.htlklu.server;

import java.io.IOException;
import java.net.ServerSocket;

public class MultithreadedServer {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(8989);
            while(true){
                new Thread(new MultithreadedClientHandler(server.accept())).start();

            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
