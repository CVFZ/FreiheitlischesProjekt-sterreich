package at.htlklu;

import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread{
    private Socket client;

    private boolean run = true;

    public void setRun(boolean run) {
        this.run = run;
    }

    public ClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        Protocol protocol = new Protocol(this);
        this.setName("Thread - "+Math.round(5+Math.random()*(10-5)));
        /*
        0 -> 5
        1 -> 10
        0-1:
        0: 5 + (Math.random())=0 = 5
        1: 5 + (Math.random())=1*(10-5) =10
        --> min-max: min + Math.random()*(max-min)
         */
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            writer.write("Gib mir ein H");;
            writer.newLine();
            writer.flush();
            while(run){
                String line = reader.readLine();
                String output = protocol.generateOutput(line);
                writer.write(output);
                writer.newLine();
                writer.flush();
            }
            writer.close();
            reader.close();
            client.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
