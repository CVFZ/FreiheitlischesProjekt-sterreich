package at.htlklu;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(7575);
            while(true){
                Socket socket = server.accept();
                ClientHandler client = new ClientHandler(socket);
                client.start();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
