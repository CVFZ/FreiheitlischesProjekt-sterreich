package at.htlklu;

public enum State {
    START,
    H,
    E,
    L1,
    L2,
    O,
    END
}
