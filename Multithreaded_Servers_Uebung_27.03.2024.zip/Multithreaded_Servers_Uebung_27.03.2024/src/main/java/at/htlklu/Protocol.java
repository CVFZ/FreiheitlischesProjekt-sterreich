package at.htlklu;

public class Protocol {
    public static int counter = 0;
    public static synchronized int incrementCounter(){
        counter++;
        return counter;
    }
    public Protocol(ClientHandler clientHandler) {
        this.clientHandler = clientHandler;
    }
    private ClientHandler clientHandler;
    private State state = State.START;
    public String generateOutput(String input) throws InterruptedException {
        if(input.equalsIgnoreCase("H") && state==State.START){
            state=State.H;
            return "Gib mir ein E";
        }
        else if(input.equalsIgnoreCase("E") && state == State.H){
            state=State.E;
            return "Gib mir ein L";
        }
        else if(input.equalsIgnoreCase("L") && state == State.E){
            state=State.L1;
            return "Gib mir ein L";
        }
        else if(input.equalsIgnoreCase("L") && state == State.L1){
            state=State.L2;
            return "Gib mir ein O";
        }
        else if(input.equalsIgnoreCase("O") && state == State.L2){
            state=State.O;
            state=State.END;
            clientHandler.setRun(false);
            return "HELLO World";
        }
        else if(input.equalsIgnoreCase("EXIT")){
            state=State.START;
            clientHandler.setRun(false);
            return "Bye!";
        }
        else if(input.equalsIgnoreCase("SLEEP")){
            state=State.START;
            Thread.sleep(1000);
            return "We waited 1s";
        }
        else if(input.equalsIgnoreCase("Thread-Name")){
            state=State.START;
            return Thread.currentThread().getName();
        }
        else if(input.equalsIgnoreCase("Plus")){
            return "Incremented Value: "+Protocol.incrementCounter();
        }
        else{
            state=State.START;
            return "Fehler. Starten wir neu. Gib mit ein H";
        }
    }
}
